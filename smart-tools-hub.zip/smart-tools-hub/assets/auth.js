/* ------------------------------------------------------------------
   Smart Tools Hub — Demo Auth (front-end only)
   NOTE: This is a client-side demo. Accounts are stored in the
   browser's localStorage on this device only. There is no real
   server, so this is NOT secure and NOT shared across devices/browsers.
   Replace with real backend auth (e.g. Firebase Auth, Supabase, or a
   custom API) before launching a production version of the site.
------------------------------------------------------------------- */
(function(){
  const USERS_KEY = 'stlz_users';
  const SESSION_KEY = 'stlz_session';

  function getUsers(){ try{ return JSON.parse(localStorage.getItem(USERS_KEY)) || {}; }catch(e){ return {}; } }
  function saveUsers(u){ localStorage.setItem(USERS_KEY, JSON.stringify(u)); }
  function simpleHash(str){ return btoa(unescape(encodeURIComponent(str))); }
  function getSession(){ return localStorage.getItem(SESSION_KEY); }

  function injectMarkup(){
    if(document.getElementById('authModalBg')) return;
    const div = document.createElement('div');
    div.innerHTML = `
    <div class="auth-modal-bg" id="authModalBg">
      <div class="auth-modal">
        <button class="auth-close" id="authClose">✕</button>
        <h3 id="authTitle">مرحبًا بك 👋</h3>
        <p class="sub">سجّل دخولك أو أنشئ حسابًا لحفظ تفضيلاتك.</p>
        <div class="auth-tabs">
          <button class="auth-tab active" data-tab="login">تسجيل الدخول</button>
          <button class="auth-tab" data-tab="signup">إنشاء حساب</button>
        </div>
        <form class="auth-form active" id="loginForm">
          <input type="email" id="loginEmail" placeholder="البريد الإلكتروني" required>
          <input type="password" id="loginPass" placeholder="كلمة المرور" required>
          <div class="auth-error" id="loginError"></div>
          <button type="submit" class="auth-btn primary">تسجيل الدخول</button>
        </form>
        <form class="auth-form" id="signupForm">
          <input type="text" id="signupName" placeholder="الاسم" required>
          <input type="email" id="signupEmail" placeholder="البريد الإلكتروني" required>
          <input type="password" id="signupPass" placeholder="كلمة مرور (٦ أحرف فأكثر)" required>
          <div class="auth-error" id="signupError"></div>
          <button type="submit" class="auth-btn primary">إنشاء الحساب</button>
        </form>
        <div class="auth-note">حساب تجريبي محفوظ في متصفحك فقط (localStorage) لأغراض العرض، وليس نظام تسجيل حقيقيًا مرتبطًا بخادم.</div>
      </div>
    </div>`;
    document.body.appendChild(div.firstElementChild);

    document.getElementById('authClose').addEventListener('click', closeAuthModal);
    document.getElementById('authModalBg').addEventListener('click', e=>{ if(e.target.id==='authModalBg') closeAuthModal(); });
    document.querySelectorAll('.auth-tab').forEach(tab=>{
      tab.addEventListener('click', ()=>{
        document.querySelectorAll('.auth-tab').forEach(t=>t.classList.remove('active'));
        document.querySelectorAll('.auth-form').forEach(f=>f.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById(tab.dataset.tab+'Form').classList.add('active');
      });
    });
    document.getElementById('loginForm').addEventListener('submit', e=>{
      e.preventDefault();
      const email = document.getElementById('loginEmail').value.trim().toLowerCase();
      const pass = document.getElementById('loginPass').value;
      const users = getUsers();
      const err = document.getElementById('loginError');
      if(!users[email] || users[email].pass !== simpleHash(pass)){ err.textContent = 'البريد أو كلمة المرور غير صحيحة'; return; }
      err.textContent = '';
      localStorage.setItem(SESSION_KEY, email);
      closeAuthModal();
      renderAuthSlot();
    });
    document.getElementById('signupForm').addEventListener('submit', e=>{
      e.preventDefault();
      const name = document.getElementById('signupName').value.trim();
      const email = document.getElementById('signupEmail').value.trim().toLowerCase();
      const pass = document.getElementById('signupPass').value;
      const err = document.getElementById('signupError');
      const users = getUsers();
      if(pass.length < 6){ err.textContent = 'كلمة المرور يجب أن تكون 6 أحرف فأكثر'; return; }
      if(users[email]){ err.textContent = 'يوجد حساب مسجّل بهذا البريد مسبقًا'; return; }
      users[email] = { name, pass: simpleHash(pass) };
      saveUsers(users);
      localStorage.setItem(SESSION_KEY, email);
      err.textContent = '';
      closeAuthModal();
      renderAuthSlot();
    });
  }

  window.openAuthModal = function(){
    injectMarkup();
    document.getElementById('authModalBg').classList.add('show');
  };
  function closeAuthModal(){
    const m = document.getElementById('authModalBg');
    if(m) m.classList.remove('show');
  }
  window.logoutUser = function(){
    localStorage.removeItem(SESSION_KEY);
    renderAuthSlot();
  };

  function renderAuthSlot(){
    const slot = document.getElementById('authSlot');
    if(!slot) return;
    const email = getSession();
    const users = getUsers();
    if(email && users[email]){
      const name = users[email].name || email;
      slot.innerHTML = `<div class="user-chip" onclick="logoutUser()" title="اضغط لتسجيل الخروج">
        <div class="avatar">${name.trim()[0].toUpperCase()}</div>
        <span>${name}</span>
      </div>`;
    } else {
      slot.innerHTML = `<button class="auth-btn" onclick="openAuthModal()">تسجيل الدخول</button>
        <button class="auth-btn primary" onclick="openAuthModal()">إنشاء حساب</button>`;
    }
  }

  document.addEventListener('DOMContentLoaded', () => { injectMarkup(); renderAuthSlot(); });
})();
